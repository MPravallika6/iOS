//
//  ViewController.swift
//  ActivitySimpleApp
//
//  Created by Maddelavedu,Pravallika on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayPN1: UITextField!
    
    
    @IBOutlet weak var DisplayPP1: UITextField!
    
    
    @IBOutlet weak var DisplayPN2: UITextField!
    
    
    @IBOutlet weak var DisplayPP2: UITextField!
    
    
    @IBOutlet weak var ShowResult: UILabel!
    
    @IBOutlet weak var ShowResult1: UILabel!
    
    @IBOutlet weak var ShowResult2: UILabel!
    @IBOutlet weak var ClickPrint: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func OnClickPrint(_ sender: UIButton) {
        var name = Int(DisplayPP1.text!)!
               var price = Int(DisplayPP2.text!)!
               var discount = Double(25)
               var tax = Double(8.5)
              
               var d = Double(name + price)
               var disco = Double(d * discount)/100
               var f = Double(d - disco)
               var tax1 = Double(f * tax)/100
               var total = Double(f + tax1)
               var round = Double(round(100 * total) / 100)
               ShowResult.text! = "\(DisplayPN1.text!) : \(name)"
               ShowResult1.text! = "\(DisplayPN2.text!) : \(price)"
               
            ShowResult2.text! = "Total price after tax and discount: \(round)"
    }
    
}

