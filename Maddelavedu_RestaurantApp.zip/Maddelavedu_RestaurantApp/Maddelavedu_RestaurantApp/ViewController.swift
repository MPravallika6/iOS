//
//  ViewController.swift
//  Maddelavedu_RestaurantApp
//
//  Created by Maddelavedu,Pravallika on 4/26/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantArr.count;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = RestaurantTableView.dequeueReusableCell(withIdentifier: "TableCell", for: indexPath)
        cell.textLabel?.text = restaurantArr[indexPath.row].name
        return cell
    }
    
//    var restaurant = Restarant()
    var restaurantArr = restaurants


    @IBOutlet weak var RestaurantTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Restaurant Sections"
        // Do any additional setup after loading the view.
        RestaurantTableView.delegate = self
        RestaurantTableView.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "tableSegue"{
            let destination = segue.destination as! RestaurantDetailsViewController
            destination.details = restaurantArr[(RestaurantTableView.indexPathForSelectedRow?.row)!]

        }
    }


}

