//
//  RestaurantDetailsViewController.swift
//  Maddelavedu_RestaurantApp
//
//  Created by Maddelavedu,Pravallika on 4/26/22.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {
    var details : Restarant?
    

    @IBOutlet weak var RestaurantImageView: UIImageView!
    
    
    @IBOutlet weak var BUttonOutlet: UIButton!
    
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    
    @IBOutlet weak var Label4: UILabel!
    
    
    @IBOutlet weak var Label5: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var Image = details?.details?.image
        RestaurantImageView.image = UIImage(named: Image!)
        Label1.isHidden = true
        Label2.isHidden = true
        Label3.isHidden = true
        Label4.isHidden = true
        Label5.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    @IBAction func ButtonAction(_ sender: Any) {
        Label1.text = details?.details?.item1
        Label2.text = details?.details?.item2
        Label3.text = details?.details?.item3
        Label4.text = details?.details?.item4
        Label5.text = details?.details?.item5
        Label1.isHidden = false
        Label2.isHidden = false
        Label3.isHidden = false
        Label4.isHidden = false
        Label5.isHidden = false

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
