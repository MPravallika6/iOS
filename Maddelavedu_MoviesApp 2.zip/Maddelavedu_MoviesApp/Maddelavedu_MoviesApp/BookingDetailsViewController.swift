//
//  BookingDetailsViewController.swift
//  Maddelavedu_MoviesApp
//
//  Created by Maddelavedu,Pravallika on 4/7/22.
//

import UIKit

class BookingDetailsViewController: UIViewController {

  
    @IBOutlet weak var showNameOutlet: UILabel!
    
    @IBOutlet weak var movieNameOutlet: UILabel!
    
    @IBOutlet weak var noTicketsOutlet: UILabel!
    
    @IBOutlet weak var totalCostOutlet: UILabel!
    
    var ShowName = ""
    var MovieName = ""
    var NumberofTickets = ""
    var totalCost = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        showNameOutlet.text = showNameOutlet.text! + ShowName
        movieNameOutlet.text! = movieNameOutlet.text! + MovieName
        noTicketsOutlet.text! = noTicketsOutlet.text! + NumberofTickets
        totalCostOutlet.text! = totalCostOutlet.text! + totalCost
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
