//
//  ViewController.swift
//  Maddelavedu_MoviesApp
//
//  Created by Maddelavedu,Pravallika on 4/7/22.
//

import UIKit

class MovieShowsViewController: UIViewController {
    
   

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var noticketsOutlet: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevButtonOutlet: UIButton!
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    
    @IBOutlet weak var bookticketOutlet: UIButton!
    
    var details = [["Avatar","12"],["No Time To Die","10"],["Shang Chi","15"],["Joker","20"]]
    var ImageNumber = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI(0)
        // Do any additional setup after loading the view.
        
        prevButtonOutlet.isEnabled = false;
    }
    @IBAction func previousAction(_ sender: Any) {
        nextButtonOutlet.isEnabled = true
        ImageNumber = -1
        updateUI(ImageNumber)
        if(ImageNumber == 0){
            prevButtonOutlet.isEnabled = false
        }
    }
    
    @IBAction func nextAction(_ sender: Any) {
        ImageNumber += 1
        updateUI(ImageNumber)
        prevButtonOutlet.isEnabled = true
        if(ImageNumber == details.count-1){
            nextButtonOutlet.isEnabled = false
        }
    }
    
    @IBAction func bookTicketAction(_ sender: Any) {
        
    }
    func updateUI(_ imageNumber:Int){
        resultImage.image = UIImage(named: details[imageNumber][0])
        nameOutlet.text = details[imageNumber][0]
        noticketsOutlet.text = details[imageNumber][1]
            
        }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    }
}

