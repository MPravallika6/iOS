//
//  ViewController.swift
//  Maddelavedu_CalculatorApp
//
//  Created by Maddelavedu,Pravallika on 2/17/22.
//

import UIKit

class ViewController: UIViewController {

    // view Label
    
    @IBOutlet weak var viewLoad: UILabel!
    
    var operand1 = ""
    var operand2 = ""
    var result = ""
    var operation = ""
    var currNum = ""
    var opChange = false
    var inChainmode = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

        //AC Button
    @IBAction func AC(_ sender: UIButton) {
        clearAll()
    }
    func clearAll(){
        operand1 = ""
        operand2 = ""
        opChange = false
        operation = ""
        currNum = ""
        viewLoad.text = ""
        inChainmode = false
    }
    func setData(_ number: String){
        if viewLoad.text == "0"{
            viewLoad.text = ""
        }
        else{
            if !opChange{
                viewLoad.text! += number
                operand1 += number
            }
            else{
                if !inChainmode{
                    viewLoad.text! += number
                    operand2 += number
                }
                else{
                    viewLoad.text = ""
                    viewLoad.text! += number
                    operand2 += number
                }
            }
        }
    }
    
    func calTemp(_ operation:String)->String {
        if operand1 != "" && operand2 != ""{
            if operation == "+"{
                operand1 = String(Double(operand1)! + Double(operand2)!)
                currNum = operand2
                operand2 = ""
                return String(operand1)
            }
            if operation == "-"{
                operand1 = String(Double(operand1)! - Double(operand2)!)
                currNum = operand2
                operand2 = ""
                
                return String(operand1)
            }
            if operation == "*"{
                operand1 = String(Double(operand1)! * Double(operand2)!)
                currNum = operand2
                operand2 = ""
                return String(operand1)
            }
            if operation == "/"{
                operand1 = String(Double(operand1)! / Double(operand2)!)
                currNum = operand2
                operand2 = ""
                return String(operand1)
            }
            if operation == "%" {
                let s1 = Double(operand1)!
                let s2 = Double(operand2)!
                var r = s1.remainder(dividingBy: s2)
                operand1 = String(r)
                currNum = operand2
                operand2 = ""
                return String(operand1)
            }
        }
        return ""
    }
    func resultFormatter(_ result:String)->String {
        let value = Double(result)!
        var resultStr = String(round(value * 100000) / 100000.0)
        
        if resultStr.contains(".0"){
            resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
        }
        
        return resultStr
}
    
    @IBAction func C(_ sender: UIButton) {
        operand2 = ""
        viewLoad.text = ""
    }
    @IBAction func plusorminus(_ sender: UIButton) {
        if operand1 == ""{
            viewLoad.text = "-" + viewLoad.text!
            operand1 = "\(viewLoad.text!)"
        }
        else{
            viewLoad.text = "-" + viewLoad.text!
            operand2 = "\(viewLoad.text!)"
        }
    }
    @IBAction func Div(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "/"
        viewLoad.text = (temp != "") ? resultFormatter(temp) : ""
          if temp != "" {
              //            inChainmode = true
              if operand2 != ""{
                  inChainmode = true
                  
                  if opChange {
                      result = String(Double(temp)! / Double(operand2)!)
                      print(result)
                      if result == "inf"{
                        viewLoad.text! = "Error"
                      }else{
                        viewLoad.text! = resultFormatter(result)
                      }
                  }
              }
          }
          opChange = true
        
    }
    
    @IBAction func multiply(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "*"
        currNum=""
        viewLoad.text = (temp != "") ? resultFormatter(temp) : ""
         
        opChange = true
    }
    @IBAction func minus(_ sender: UIButton) {
        let temp = calTemp(operation)
        operation = "-"
       viewLoad.text = (temp != "") ? resultFormatter(temp) : ""
        if temp != "" {
            if operand2 != ""{
                inChainmode = true
                currNum = operand2;
                if opChange {
                    result = String(Double(temp)! - Double(operand2)!)
                   viewLoad.text! = resultFormatter(result)
                }
            }
        }
        opChange = true
    }
    @IBAction func plus(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "+"
        currNum=""
        viewLoad.text = (temp != "") ? resultFormatter(temp) : ""
        opChange = true
    }
    
    @IBAction func equals(_ sender: UIButton) {
        var res = ""
        switch operation {
        case "+":
            
            if currNum != "" {
                res = String(Double(operand1)! + Double(currNum)!)
                viewLoad.text = resultFormatter(res)
                 operand2 = currNum
            }else{
                res = String(Double(operand1)! + Double(operand2)!)
                viewLoad.text = resultFormatter(res)
            }
            operand1 = res
            
            break
        case "*":
            if currNum != "" {
                res = String(Double(operand1)! * Double(currNum)!)
                viewLoad.text = resultFormatter(res)
            }else{
                res = String(Double(operand1)! * Double(operand2)!)
                viewLoad.text = resultFormatter(res)
            }
            operand1 = res
            
            break
        case "-":
            if currNum != "" {
                res = String(Double(operand1)! - Double(currNum)!)
                viewLoad.text = resultFormatter(res)
                
            }else{
                res = String(Double(operand1)! - Double(operand2)!)
                viewLoad.text = resultFormatter(res)
               
            }
            operand1 = res
            break
        case "/":
            if viewLoad.text == "Error"{
                clearAll()
            }else{
                if currNum != "" {
                    res = String(Double(operand1)! / Double(currNum)!)
                    if res == "inf"{
                        viewLoad.text! = "Error"
                        return
                    }else{
                        viewLoad.text = resultFormatter(res)
                    }
                }else{
                    res = String(Double(operand1)! / Double(operand2)!)
                    if res == "inf"{
                        viewLoad.text! = "Error"
                        return
                    }else{
                        viewLoad.text = resultFormatter(res)
                    }
                }
                operand1 = res
            }
            break
        case "%":
            if currNum != "" {
                viewLoad.text = resultFormatter(res)
                let s1 = Double(operand1)!
                let s2 = Double(currNum)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                 operand2 = currNum
            }else{
                let s1 = Double(operand1)!
                let s2 = Double(operand2)!
                var r = s1.remainder(dividingBy: s2)
                res = String(r)
                viewLoad.text = resultFormatter(res)
            }
            operand1 = res
            
            break
            
        default:
            print("IOS")
        }
    
    }
    
    @IBAction func remainder(_ sender: UIButton) {
        let temp = calTemp(operation)
        print("temp is \(temp)")
        operation = "%"
        currNum=""
        viewLoad.text = (temp != "") ? resultFormatter(temp) : ""
         
        opChange = true
    }
    @IBAction func Dot(_ sender: UIButton) {
        setData(".")
    }
    
    @IBAction func Seven(_ sender: UIButton) {
        setData("7")
    }
    @IBAction func Eight(_ sender: UIButton) {
        setData("8")
    }
    
    @IBAction func Nine(_ sender: UIButton) {
        setData("9")
    }
    @IBAction func Four(_ sender: UIButton) {
        setData("4")
    }
    
    @IBAction func Five(_ sender: UIButton) {
        setData("5")
    }
    @IBAction func Six(_ sender: UIButton) {
        setData("6")
    }
    
    @IBAction func One(_ sender: UIButton) {
        setData("1")
    }
    @IBAction func Two(_ sender: UIButton) {
        setData("2")
    }
    @IBAction func Three(_ sender: UIButton) {
        setData("3")
    }
    @IBAction func zero(_ sender: UIButton) {
        setData("0")
    }
    


}

