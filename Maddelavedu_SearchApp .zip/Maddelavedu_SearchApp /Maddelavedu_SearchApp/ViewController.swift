//
//  ViewController.swift
//  Maddelavedu_SearchApp
//
//  Created by Maddelavedu,Pravallika on 3/2/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchOption: UIButton!

    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevImage: UIButton!
    
    @IBOutlet weak var nextImage: UIButton!
    
    @IBOutlet weak var topicinfoText: UITextView!
    
    @IBOutlet weak var resetAction: UIButton!
    
    var imageNumber = 0;
    var topic: Int = -1
    var count1 : Int = -1
    var arr = [
               ["flower1","flower2","flower3","flower4","flower5"],
               ["animal1","animal2","animal3","animal4","animal5"],
               ["reallife1","reallife2","reallife3","reallife4","reallife5"]]
    
    var flower_keywords = ["flower","size","color","scientific name"]
    var animal_keywords = ["scientific name","animal","lifespan","typeofanimal"]
    var reallife_keywords = ["reallife","dateofbirth","rewards","quotation"]
    var topics_array = [["jaswine scientific name is Jasminum. It is a genus of shrubs and vines in the olive family.It contains around 200 species native to tropical and warm temperate.","Sunflower scientific name is Helianthus.It is a genus comprising about 70 species of annual and perennial flowering plants in the daisy family asteracease.","Bougainvillea glabra scientific name is Bougainvillea glabra. The he lesser bougainvillea or paperflower, is the most common species of bougainvillea used for bonsai. The epithet 'glabra' comes from Latin and means bald.","Rose scientific name is Rosa.A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.","Lotus scientific name is Nelumbo nucifera.It is also known as Indian lotus, sacred lotus, or simply lotus, is one of two extant species of aquatic plant in the family Nelumbonaceae."],
        ["Dog scientific name is Canis lupus familiaris. The dog or domestic dog is a domesticated descendant of the wolf which is characterized by an upturning tail.","Birds are a group of warm-blooded vertebrates constituting the class Aves, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton.","Dolphin scientific name is Delphinus. The common dolphin is the most abundant cetacean in the world, with a global population of about six million.","Giraffe scientific name is Giraffa. The giraffe is a tall African hoofed mammal belonging to the genus Giraffa. It is the tallest living terrestrial animal and the largest ruminant on Earth.","Peacock scientific name is Pavo cristatus.The Indian peafowl, also known as the common peafowl, and blue peafowl, is a peafowl species native to the Indian subcontinent. It has been introduced to many other countries."],
        ["Mother Mary Teresa Bojaxhiu, honoured in the Catholic Church as Saint Teresa of Calcutta, was an Albanian-Indian Roman Catholic nun and missionary. She was born in Skopje, then part of the Kosovo Vilayet of the Ottoman Empire.","Avul Pakir Jainulabdeen Abdul Kalam was an Indian aerospace scientist who served as the 11th president of India from 2002 to 2007. He was born and raised in Rameswaram, Tamil Nadu and studied physics and aerospace engineering.","Swami Vivekananda, born Narendranath Datta, was an Indian Hindu monk and philosopher. He was a chief disciple of the 19th-century Indian mystic Ramakrishna.","Albert Einstein was a German-born theoretical physicist, widely acknowledged to be one of the greatest physicists of all time. Einstein is best known for developing the theory of relativity, but he also made important contributions to the development of the theory of quantum mechanics.","Mohandas Karamchand Gandhi was an Indian lawyer, anti-colonial nationalist and political ethicist who employed nonviolent resistance to lead the successful campaign for India's independence from British rule, and to later inspire movements for civil rights and freedom across the world."]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        searchOption.isEnabled = false
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        resultImage.image = UIImage(named: "default")

        //On Loading the app we need to display default Image
    }


    @IBAction func searchFieldAction(_ sender: Any) {
        searchOption.isEnabled = true
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if(flower_keywords.contains(searchTextField.text!)){
            topic = 0
            imageNumber = 0
            buttonsDisable()
        }
        else if(animal_keywords.contains(searchTextField.text!)){
            topic = 1
            imageNumber = 0
            buttonsDisable()
        }
        else if(reallife_keywords.contains(searchTextField.text!)){
            topic = 2
            imageNumber = 0;
            buttonsDisable()
        }
        else{
            topic = -1
            resultImage.image = UIImage(named: "default")
            topicinfoText.text = "No matches with the given Key words. Please try again."
            resetAction.isHidden = true
            nextImage.isHidden = true
            prevImage.isHidden = true
        }
        
        if(topic != -1)
        {
            prevImage.isEnabled = false
            nextImage.isEnabled = true
            count1 = arr[topic].count
            resultImage.image = UIImage(named: arr[topic][0])
            topicinfoText.text = topics_array[topic][0]
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
            nextImage.isEnabled = true;
            imageNumber -= 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == 0){
                        prevImage.isEnabled = false
                }
    
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
            prevImage.isEnabled = true
            imageNumber += 1
            resultImage.image = UIImage(named: arr[topic][imageNumber])
            topicinfoText.text = topics_array[topic][imageNumber]
            if(imageNumber == count1-1){
                nextImage.isEnabled = false
            }
    }
    
    @IBAction func resetButton(_ sender: Any) {
        nextImage.isHidden = true
        prevImage.isHidden = true
        resetAction.isHidden = true
        searchTextField.text = ""
        searchOption.isEnabled = false
        topicinfoText.text = ""
        resultImage.image = UIImage(named: "default")
        
    }
    func buttonsDisable(){
        nextImage.isHidden = false
        prevImage.isHidden = false
        resetAction.isHidden = false
    }
    


}

