//
//  MovieData.swift
//  Maddelavedu_Movies
//
//  Created by Maddelavedu,Pravallika on 4/21/22.
//

import Foundation
