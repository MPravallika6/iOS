//
//  MovieData.swift
//  Maddelavedu_Movies
//
//  Created by Maddelavedu,Pravallika on 4/21/22.
//

import Foundation
import UIKit
struct Movie {
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let moviePlot:String
    let cast:[String]
}

struct Genre{
    let category:String
    let movies:[Movie]
}

let movieList1 = Genre(category:"ACTION" , movies: [Movie(title: "KGF", image:UIImage(named: "action3")!, releasedYear : "2018", movieRating: "8.4", boxOffice: "250 cr", moviePlot: "The Blood-soaked land of kolar Gold fields has a new overlord now rocky, whose name strikes fear in the heart of his foes", cast: ["Yash", "Srinidhi Shetty", "Sanjay Dutt", "raveena Tandon", "Anant Nag"]), Movie(title:"RRR", image:UIImage(named: "action1")!, releasedYear: "2022", movieRating: "8.9", boxOffice: "238.09 cr", moviePlot: "A tale of two legendary revolutionaries and their journey far away from home", cast: ["Ram Charan", "NTR", "Alia Bhatt", "ajay devgn", "Olivia Morris"]),Movie(title: "Pushpa", image:UIImage(named: "action2")!, releasedYear: "2021", movieRating: "7.9", boxOffice: "106 cr", moviePlot: "Violence erupts between red sandalwood smugglers and the police charged with bringing down their organisation in the Seshachalam forests of South India.", cast: ["Allu Arjun","Rashmika Mandanna","Samantha ruth","Sunil","anasuya Bharadwaj"]),Movie(title: "Beast", image:UIImage(named: "action4")!, releasedYear: "2022", movieRating: "6.8", boxOffice: "202 cr", moviePlot:"When he comes under suspicion for a series of murders, she defends him at all costs" , cast: ["Vijay","Pooja Hegde","shine tom Chacko","Selvaraghavan"]),Movie(title: "Akhanda", image:UIImage(named: "action5")!, releasedYear: "2021", movieRating: "7.3", boxOffice: "150 cr", moviePlot:"A child is taken in by Aghora, becoming a fierce devotee of Lord Shiva, living up to his destiny to stand tall against evildoers." , cast: ["Nandamuri Balakrishna","Pragya Jaiswal","Sharnmna Kasim","Nithin Mehta"])])

let movieList2 = Genre(category:"HORROR" , movies: [Movie(title: "NO ONE GETS OUT ALIVE", image:UIImage(named: "horror1")!, releasedYear: "2021", movieRating: "5.3", boxOffice: "120 cr", moviePlot: "Desperate and without documentation, a woman from Mexico moves into a rundown Cleveland boarding house. Then the unsettling cries and eerie visions begin.", cast: ["Cristina Rodlo","Marc Menchaca","David Figlioli"]), Movie(title: "NOCTURNE", image:UIImage(named: "horror2")!, releasedYear: "2020", movieRating: "5.7", boxOffice: "150 cr", moviePlot: "Inside the halls of an elite arts academy, a timid music student begins to outshine her more accomplished and outgoing twin sister when she discovers a mysterious notebook belonging to a recently deceased classmate.", cast: ["Sydney Sweeney","Madison Iseman","Jacques coimon"]),Movie(title: "THE CONJURING2", image:UIImage(named: "horror3")!, releasedYear: "2016", movieRating: "7.3", boxOffice: "250 cr", moviePlot: "", cast: ["Patrick wilson","Vera farmiga","Madison wolfe"]),Movie(title: "THE HOST", image:UIImage(named: "horror4")!, releasedYear: "2006", movieRating: "7.1", boxOffice: "80 cr", moviePlot: "Careless American military personnel dump chemicals into South Korea's Han River", cast: ["Song Kang-Ho","Bae Doona","Go Ah-sung"]),Movie(title: "FINAL DESTINATION", image:UIImage(named: "horror5")!, releasedYear: "2006", movieRating: "8.5", boxOffice: "200 cr", moviePlot:"Final Destination is an American horror franchise consisting of five films, two comic books, and nine novels" , cast: ["Ali Larter","devon Sawa","tony todd","Kerr Smith"])])

let movieList3 = Genre(category:"COMEDY" , movies: [Movie(title: "Jathi Ratnalu", image:UIImage(named: "comedy1")!, releasedYear: "2021", movieRating: "7.5", boxOffice: "250 cr", moviePlot: "After being released from prison, three men start to plan their lives on the outside, searching for love and happiness", cast: ["Naveen Polishetty","Faria Abdullah","Rahul Ramakrishna","Priyadarshi Pulikonda"]), Movie(title: "Pressure Cooker", image:UIImage(named: "comedy2")!, releasedYear: "2020", movieRating: "6.4", boxOffice: "200 cr", moviePlot: "Pressure Cooker is a 2020 Indian Telugu-language comedy drama film directed by Sujoi Karampuri and Sushil Karampuri", cast: ["Preethi asrani","Sai ronak","Rahul Ramakrishna"]),Movie(title: "Stand up Rahul", image:UIImage(named: "comedy3")!, releasedYear: "2022", movieRating: "5.7", boxOffice: "150 cr", moviePlot: "Stand Up Rahul is a 2022 Indian Telugu-language coming of age romantic comedy film directed by debutant Santo", cast: ["Raj Tarun","Varsha Bollamma","Indraja"]),Movie(title: "Brochevarevarura", image:UIImage(named: "comedy4")!, releasedYear: "2019", movieRating: "8", boxOffice: "168 cr", moviePlot: "Three intermediate students who can't seem to get their lives together cook up a scheme to help a woman escape her overbearing father only to find themselves in deep trouble", cast: ["Sree Vishnu","Nivetha Thomas","Satyadev Kancharana"]),Movie(title: "Rowdy Boys", image:UIImage(named: "comedy5")!, releasedYear: "2021", movieRating: "5.8", boxOffice: "150 cr", moviePlot: "Akshay and Kavya fall in love amid gang conflicts between medical and engineering students", cast: ["Ashish Reddy","Anupama Parameswara","Sahidev vikram"])])

let movies = [movieList1, movieList2, movieList3]
