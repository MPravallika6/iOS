//
//  Student.swift
//  StudentMultipleApp
//
//  Created by Maddelavedu,Pravallika on 3/24/22.
//

import Foundation
struct Student {
    var name = ""
    var sid = ""
    var email = ""
    
   
    var courses:[Course] = []
    
}
struct Course{
    var title = ""
    var sem = ""
}


let student1 = Student(name:"Pravallika",sid:"s545254",email: "s545254@gmail.com",
                     courses:[
                        Course(title:"Mobile Computing",sem:"spring2022"),
                        Course(title:"Project management",sem:"spring2022"),
                        Course(title:"Java",sem:"fall2021")
                     ])


let student2 = Student(name:"Harshitha",sid:"s545413",email: "s545413@gmail.com",
                     courses:[
                        Course(title:"Design Patterns",sem:"spring2022"),
                        Course(title:"GDP1",sem:"summer2022"),
                        Course(title:"webapps",sem:"fall2021")
                     ])


let student3 = Student(name:"Prabhakar",sid:"s545407",email: "s545407@gmail.com",
                     courses:[
                        Course(title:"Data base",sem:"fall2021"),
                        Course(title:"GDP2",sem:"fall2022"),
                        Course(title:"bigData",sem:"fall2022")
                     ])


// students array we use in the LoginController
let students = [student1,student2,student3]
